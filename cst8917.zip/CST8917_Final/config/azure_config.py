import os

def get_azure_config():
    return {
        "SERVICE_BUS_CONNECTION_STRING": "Endpoint=sb://cst8922servicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=4QsuhrnSncilGQsP1tgIPTtKUEu9fmxJz+ASbLzcL8s=",
        "SERVICE_BUS_QUEUE_NAME": "cst8922servicebusqueue",
        "COSMOS_DB_CONNECTION_STRING": "mongodb://kaya0043cosmosdb:Wplku8op2sWklj5SCFQU5lQGWlulhGWCXJKjUUH1IEB44mfVNmtMFoasVW6TEhDo2iq4TOiwdaxdACDbvKGSoA==@kaya0043cosmosdb.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@kaya0043cosmosdb@",
        "COSMOS_DB_NAME": "TelemetryDB",
        "COLLECTION_NAME": "Users",
        "COLLECTION_SHARD_KEY": "userId",
        "CONDITION_COLLECTION_NAME": "Conditions",
        "ALERT_COLLECTION_NAME": "AlertLogs",
        "LOGS_COLLECTION_NAME": "Logs",
        "COMMUNICATION_SERVICE_ENDPOINT": "https://kaya0043commservice.unitedstates.communication.azure.com/",
        "COMMUNICATION_SERVICE_PRIMARY_KEY": "LMkb4gAqyJVhI7v3VofrTRRVMJEbUZsDglcMd6icZomuyeHCsSxgJQQJ99BDACULyCpIQ1JtAAAAAZCSTIpI",
        "COMMUNICATION_SERVICE_CONNECTION_STRING": "endpoint=https://kaya0043commservice.unitedstates.communication.azure.com/;accesskey=LMkb4gAqyJVhI7v3VofrTRRVMJEbUZsDglcMd6icZomuyeHCsSxgJQQJ99BDACULyCpIQ1JtAAAAAZCSTIpI",
        "COMMUNICATION_SERVICE_SENDER_EMAIL":"DoNotReply@7273f83d-9db5-4ca7-801d-1d9d967d1598.azurecomm.net",
        "IOTHUB_CONNECTION_STRING": "HostName=Group2IoTHub.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=XVzsGYk70H6KzeN6drSbvu3X5A67wWKHTAIoTNVhbYA=",
        "IOTHUB_EVENTHUB_CONNECTION_STRING": os.environ.get("IOTHUB_EVENTHUB_CONNECTION_STRING"),
        "IOTHUB_EVENTHUB_NAME": "iothub-ehub-group2ioth-61251602-76a3f50e8e",
        "EVENTGRID_TOPIC_ENDPOINT": "https://cst8922eventgridtopic.centralus-1.eventgrid.azure.net/api/events",
        "EVENTGRID_TOPIC_KEY": "Az6BBSuQjtFGdk9HLl8cUQnZyt5LzAHZNBnt7jPGrrsAeu8MDvGRJQQJ99BCAC1i4TkXJ3w3AAABAZEG15p1",
        "NOTIFICATION_HUB_CONNECTION_STRING": "Endpoint=sb://telemetryns.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=EpBz8FraIZTm+kJuqK3VjOfaUYIqShvzX0fpaoHW6xQ=",
        "NOTIFICATION_HUB_NAMESPACE": "telemetryns",
        "NOTIFICATION_HUB_NAME": "telemetryhub",
        "NOTIFICATION_HUB_HOST": "telemertyns.servicebus.windows.net",
        "JWT_SECRET": "CST8917_Final_Secret_Key", 
        "JWT_ALGORITHM": "HS256",
        "COGNITIVE_SERVICE_ENDPOINT": "https://kaya0043computervision.cognitiveservices.azure.com/",
        "COGNITIVE_SERVICE_KEY": "FCfm0jpNrS7omxlUeSAkodP6M29t0TzEeLqg7ZiXNfY5YQ4mR6cWJQQJ99BDAC1i4TkXJ3w3AAAFACOGrmRU",
        "BLOB_STORAGE_CONNECTION_STRING": "DefaultEndpointsProtocol=https;AccountName=cst8917finalstgacc;AccountKey=hmwREQ7C+uXYLkKPHZbMn6FuIgRkZPqYvVlXn8JpAVXvtWeOmLyVmFsNbzJFBn2xD7hPJN5bgUfG+AStiNPfRA==;EndpointSuffix=core.windows.net",
        "BLOB_CONTAINER_NAME": "telemetry-images",
        "BLOB_CONTAINER_PROCESSED_IMAGES": "processed-images",
        "BLOB_STORAGE_NAME": "cst8917finalstgacc"
    }

