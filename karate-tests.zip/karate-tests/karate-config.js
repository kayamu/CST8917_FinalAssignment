function fn() {
  var config = {
    baseUrl: 'https://super-duper-capybara-977jw9q7q79h76wr-7071.app.github.dev/api',
    email: 'mucteb@gmail.com',
    password: '12345'
  };

  return config;
}
